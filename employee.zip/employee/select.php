
<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "aissel123";
$dbname = "company";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT empid,empname,emailid FROM employee";
$result = $conn->query($sql);
echo "<u><b>Employee details</b></u><br/><br/>";
echo "<table border='1'>
<tr>
<th>Employee Id</th>
<th>Employee Name</th>
<th>EmailId</th>
</tr>";


if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
            echo "<tr>";
echo "<td>" . $row['empid'] . "</td>";
echo "<td>" . $row['empname'] . "</td>";
echo "<td>" . $row['emailid'] . "</td>";
echo "</tr>";
    }
} else {
    echo "0 results";
}
echo "</table>";

$conn->close();
?>

</body>
</html>
</html>
