<?php
$servername = "localhost";
$username = "root";
$password = "aissel123";
$dbname = "company";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE employee SET empname='divya' WHERE empid=112";

if ($conn->query($sql) === TRUE) {
   echo "Record updated successfully";
} else {
   echo "Error updating record: " . $conn->error;
}
$sql = "SELECT *FROM employee";
$result = $conn->query($sql);

echo "<table border='1'>
<tr>
<th>Employee Id</th>
<th>Employee Name</th>
<th>Contact no</th>
<th>EmailId</th>
<th>Address</th>
<th>Date of joining </th>
</tr>";


if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
            echo "<tr>";
echo "<td>" . $row['empid'] . "</td>";
echo "<td>" . $row['empname'] . "</td>";
echo "<td>" . $row['phno'] . "</td>";
echo "<td>" . $row['emailid'] . "</td>";
echo "<td>" . $row['Address'] . "</td>";
echo "<td>" . $row['doj'] . "</td>";

echo "</tr>";
    }
} else {
    echo "0 results";
}
echo "</table>";

$conn->close();
?>
