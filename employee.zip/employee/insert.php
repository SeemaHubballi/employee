<?php
$servername = "localhost";
$username = "root";
$password = "aissel123";
$dbname = "company";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['submit']))
{
$empid = $_POST['empid'];
$empname = $_POST['empname'];
$phno= $_POST['phno'];
$emailid = $_POST['emailid'];
$Address = $_POST['Address'];
$doj = $_POST['doj'];

$sql = "INSERT INTO employee (empid, empname,phno, emailid, Address, doj)
VALUES ('$empid', '$empname', '$phno','$emailid', '$Address', '$doj')";
$result = $conn->query($sql);
//echo $sql;
if($result)
{
  echo "<br/><br/><span>Data Inserted successfully...!!</span>";
}
else {
  echo "<br/><br/><span>something went wrong...!!</span>";
}
}
$conn->close();
?>
